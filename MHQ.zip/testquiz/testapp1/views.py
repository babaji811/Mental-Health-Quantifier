from django.shortcuts import render
from .MentalHealth import executeRF


# Create your views here.

def home(request):
    return render(request, 'home.html', {})

def about(request):
    return render(request, 'about.html', {})

def test(request):
    if request.method == 'GET':
        return render(request, 'test.html', {})
    else:
        age = request.POST['age']
        gender = request.POST['gender']
        familyhistory = request.POST['familyhistory']
        benefits = request.POST['benefits']
        careoptions = request.POST['careoptions']
        anonymity = request.POST['anonymity']
        leave = request.POST['leave']
        workinterfere = request.POST['workinterfere']
        algo = request.POST['algo']

        genderMap = {'female': 0, 'male': 1, 'trans': 2}
        famMap = {'no': 0, 'yes': 1}
        benefitsMap = {'dk': 0, 'no': 1, 'yes': 2}
        careMap = {'no': 0, 'dk': 1, 'yes': 2}
        anonMap = {'dk': 0, 'no': 1, 'yes': 2}
        leaveMap = {'dk': 0, 'sd': 1, 'se': 2, 'vd': 3, 've': 4}
        wiMap = {'dk': 0, 'nv': 1, 'of': 2, 'ra': 3, 'so': 4}

        scaled_age = (float(age))/100

        test_tup = [[scaled_age, genderMap[gender], famMap[familyhistory], benefitsMap[benefits], careMap[careoptions], anonMap[anonymity], leaveMap[leave], wiMap[workinterfere]]]
        result = executeRF(test_tup)

        predicted_class = result[0][0]
        if(predicted_class == 1):
            pred_class = algo + ' has predicted that ' + 'you should seek mental treatment ' + 'based on the inputs given for workplace factors.'
            disp_class = 'Seek Treatment'
        else:
            pred_class = algo + ' has predicted that ' + 'you might not have to seek mental treatment ' + 'based on the inputs given for workplace factors.'
            disp_class = 'Might not have to seek treatment'

        predicted_prob = result[1]
        accuracy = result[2]

        request.session['treatment_probability'] = float(predicted_prob)


        return render(request, 'testresult.html', {
            'pred_class': pred_class,
            'predicted_prob': predicted_prob,
            'accuracy': accuracy,
            'disp_class': disp_class,
            'algo': algo
            })

def addScoreSpectrum(N, rating, score, max_score, treatment_probability):
    if(treatment_probability < 0.5):
        multiplier = 1
    elif(0.5 <= treatment_probability < 0.75):
        multiplier = 1.25
    else:
        multiplier = 1.5
    
    if(rating-N < 0):
        score1 = multiplier*(rating-N)
    else:
        score1 = rating-N
    score += score1
    max_score += 10-N
    return score, max_score

def addScoreProblem(N, rating, score, max_score, treatment_probability):
    if(treatment_probability < 0.5):
        multiplier = 1
    elif(0.5 <= treatment_probability < 0.75):
        multiplier = 1.25
    else:
        multiplier = 1.5
    
    if(N-rating < 0):
        score1 = multiplier*(N-rating)
    else:
        score1 = N-rating

    score += score1
    max_score += N-1
    return score, max_score

def addDimensionSpectrumFull(N, rating, dim_name, max_dim_name):
    score = rating-N
    max_score = 10-N
    dim_name += score
    max_dim_name += max_score
    return dim_name, max_dim_name

def addDimensionSpectrumPartial(N, rating, dim_name, max_dim_name):
    score = rating-N
    max_score = 10-N
    dim_name += 0.5*score
    max_dim_name += 0.5*max_score
    return dim_name, max_dim_name

def addDimensionProblemFull(N, rating, dim_name, max_dim_name):
    score = N-rating
    max_score = N-1
    dim_name += score
    max_dim_name += max_score
    return dim_name, max_dim_name

def addDimensionProblemPartial(N, rating, dim_name, max_dim_name):
    score = N-rating
    max_score = N-1
    dim_name += 0.5*score
    max_dim_name += 0.5*max_score
    return dim_name, max_dim_name

def dimensionColor(dimScore):
    if(dimScore>50):
        dim_color = 'color:#30E67A'
    elif(0 <= dimScore < 50):
        dim_color = 'color:#31B6F3'
    else:
        dim_color = 'color:#E9AE35'

    return dim_color


def mhq(request):
    if(request.method == 'GET'):
        return render(request, 'mhq.html', {})
    else:
        #For main scores
        score = 0
        max_score = 0

        #For dimension scores
        core_cog = 0
        max_core_cog = 0
        com_cog = 0
        max_com_cog = 0
        mood = 0
        max_mood = 0
        drive = 0
        max_drive = 0
        social = 0
        max_social = 0
        mind = 0
        max_mind = 0

        #Prev obtained treatment probability from OSMI test
        treatment_probability = request.session['treatment_probability']

        adaptability = request.POST['adaptability']
        selfworth = request.POST['selfworth']
        creativity = request.POST['creativity']
        drive_motiv = request.POST['drive_motiv']
        sleep = request.POST['sleep']
        self_control = request.POST['self_control']
        relationships = request.POST['relationships']
        resilience = request.POST['resilience']
        language = request.POST['language']

        print(f'#0 {core_cog} {max_core_cog}')

        score, max_score = addScoreSpectrum(3, int(adaptability), score, max_score, treatment_probability)
        com_cog, max_com_cog = addDimensionSpectrumFull(3, int(adaptability), com_cog, max_com_cog)
        mood, max_mood = addDimensionSpectrumPartial(3, int(adaptability), mood, max_mood)

        score, max_score = addScoreSpectrum(2, int(selfworth), score, max_score, treatment_probability)
        social, max_social = addDimensionSpectrumFull(2, int(selfworth), social, max_social)
        drive, max_drive = addDimensionSpectrumPartial(2, int(selfworth), score, max_score)

        score, max_score = addScoreSpectrum(5, int(creativity), score, max_score, treatment_probability)
        com_cog, max_com_cog = addDimensionSpectrumFull(5, int(creativity), com_cog, max_com_cog)
        core_cog, max_core_cog = addDimensionSpectrumPartial(5, int(creativity), core_cog, max_core_cog)
        print(f'#1 {core_cog} {max_core_cog}')

        score, max_score = addScoreSpectrum(3, int(drive_motiv), score, max_score, treatment_probability)
        drive, max_drive = addDimensionSpectrumFull(3, int(drive_motiv), drive, max_drive)
        mood, max_mood = addDimensionSpectrumPartial(3, int(drive_motiv), mood, max_mood)
        mind, max_mind = addDimensionSpectrumPartial(3, int(drive_motiv), mind, max_mind)

        score, max_score = addScoreSpectrum(4, int(sleep), score, max_score, treatment_probability)
        mind, max_mind = addDimensionSpectrumFull(4, int(sleep), mind, max_mind)
        core_cog, max_core_cog = addDimensionSpectrumPartial(4, int(sleep), core_cog, max_core_cog)
        print(f'#2 {core_cog} {max_core_cog}')

        score, max_score = addScoreSpectrum(3, int(self_control), score, max_score, treatment_probability)
        mood, max_mood = addDimensionSpectrumFull(3, int(self_control), mood, max_mood)
        drive, max_drive = addDimensionSpectrumPartial(3, int(self_control), drive, max_drive)

        score, max_score = addScoreSpectrum(2, int(relationships), score, max_score, treatment_probability)
        social, max_social = addDimensionSpectrumFull(2, int(relationships), social, max_social)

        score, max_score = addScoreSpectrum(3, int(resilience), score, max_score, treatment_probability)
        com_cog, max_com_cog = addDimensionSpectrumFull(3, int(resilience), com_cog, max_com_cog)

        score, max_score = addScoreSpectrum(5, int(language), score, max_score, treatment_probability)
        core_cog, max_core_cog = addDimensionSpectrumFull(5, int(language), core_cog, max_core_cog)
        social, max_social = addDimensionSpectrumPartial(5, int(language), social, max_social)

        

        restlessness = request.POST['restlessness']
        fear = request.POST['fear']
        sus = request.POST['sus']
        aggression = request.POST['aggression']
        avoidance = request.POST['avoidance']
        detachment = request.POST['detachment']
        addiction = request.POST['addiction']
        suicide = request.POST['suicide']
        hallucination = request.POST['hallucination']

        score, max_score = addScoreProblem(5, int(restlessness), score, max_score, treatment_probability)
        drive, max_drive = addDimensionProblemFull(5, int(restlessness), drive, max_drive)

        score, max_score = addScoreProblem(3, int(fear), score, max_score, treatment_probability)
        mood, max_mood = addDimensionProblemFull(3, int(fear), mood, max_mood)

        score, max_score = addScoreProblem(4, int(sus), score, max_score, treatment_probability)
        mind, max_mind = addDimensionProblemFull(4, int(sus), mind, max_mind)

        score, max_score = addScoreProblem(3, int(aggression), score, max_score, treatment_probability)
        social, max_social = addDimensionProblemFull(3, int(aggression), social, max_social)
        mood, max_mood = addDimensionProblemPartial(3, int(aggression), mood, max_mood)

        score, max_score = addScoreProblem(4, int(avoidance), score, max_score, treatment_probability)
        social, max_social = addDimensionSpectrumPartial(4, int(avoidance), social, max_social)
        mood, max_mood = addDimensionSpectrumPartial(4, int(avoidance), mood, max_mood)

        score, max_score = addScoreProblem(4, int(detachment), score, max_score, treatment_probability)
        mood, max_mood = addDimensionSpectrumPartial(4, int(detachment), mood, max_mood)
        drive, max_drive = addDimensionSpectrumPartial(4, int(detachment), drive, max_drive)

        score, max_score = addScoreProblem(2, int(addiction), score, max_score, treatment_probability)
        mind, max_mind = addDimensionProblemFull(2, int(addiction), mind, max_mind)
        core_cog, max_core_cog = addDimensionProblemPartial(2, int(addiction), core_cog, max_core_cog)
        com_cog, max_com_cog = addDimensionProblemPartial(2, int(addiction), com_cog, max_com_cog)

        score, max_score = addScoreProblem(2, int(suicide), score, max_score, treatment_probability)
        mood, max_mood = addDimensionProblemFull(2, int(suicide), mood, max_mood)
        drive, max_drive = addDimensionProblemPartial(2, int(suicide), drive, max_drive)
        mind, max_mind = addDimensionProblemPartial(2, int(suicide), drive, max_drive)

        score, max_score = addScoreProblem(2, int(hallucination), score, max_score, treatment_probability)
        mind, max_mind = addDimensionProblemFull(2, int(hallucination), mind, max_mind)
        core_cog, max_core_cog = addDimensionProblemPartial(2, int(hallucination), core_cog, max_core_cog)
        



        if(score >= 0):
            result = round((score*200)/max_score)
        else:
            result = round((score*100)/max_score)

        core_cog_result = round((core_cog*100)/max_core_cog)
        core_cog_color = dimensionColor(core_cog_result)
        print(f'core cog: {core_cog} core cog max: {max_core_cog}')

        com_cog_result = round((com_cog*100)/max_com_cog)
        com_cog_color = dimensionColor(com_cog_result)

        mood_result = round((mood*100)/max_mood)
        mood_color = dimensionColor(mood_result)

        drive_result = round((drive*100)/max_drive)
        drive_color = dimensionColor(drive_result)

        social_result = round((social*100)/max_social)
        social_color = dimensionColor(social_result)

        mind_result = round((mind*100)/max_mind)
        mind_color = dimensionColor(mind_result)
        
        if(result>=150):
            result_status = 'You are thriving. Preserve and protect.'
            result_color = 'color:#30E67A'
        elif(result>=100 and result<150):
            result_status = 'You are succeeding in staying mentally well. Stay on track and re-assess from time to time.'
            result_color = 'color:#31B6F3'
        elif(result>=50 and result<100):
            result_status = 'You are managing and doing well but consider opportunities for enhancement.'
            result_color = 'color:#47DFF8'
        elif(result>=0 and result<50):
            result_status = 'You are enduring. Keep strong as you are and never hesitate to seek mental treatment.'
            result_color = 'color:#F4F4F4'
        elif(result>=-50 and result<0):
            result_status = 'You are at risk and definitely need to seek mental treatment. To understand specific areas for improvement look at your scores for each dimension given below.'
            result_color = 'color:#E9AE35'
        else:
            result_status = 'You are clinically at risk and need to seek mental treatment immediately. To understand specific areas for improvement look at your scores for each dimension given below.'
            result_color = 'color:#FE4848'


        return render(request, 'mhqresult.html', {'result': result,
                                                'core_cog_result': core_cog_result,
                                                'com_cog_result': com_cog_result, 
                                                'mood_result': mood_result, 
                                                'drive_result': drive_result, 
                                                'social_result': social_result, 
                                                'mind_result': mind_result,
                                                'result_status': result_status,
                                                'result_color': result_color,
                                                'core_cog_color': core_cog_color,
                                                'com_cog_color': com_cog_color,
                                                'mood_color': mood_color,
                                                'drive_color': drive_color,
                                                'social_color': social_color,
                                                'mind_color': mind_color
                                                })

