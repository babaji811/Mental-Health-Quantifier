from django.apps import AppConfig


class Testapp1Config(AppConfig):
    name = 'testapp1'
